# Chosen Beatz — Secure Full Stack Starter (Beginner Friendly)

## Quick start (beginner)
1. Install Node.js (LTS) from https://nodejs.org/
2. Unzip this project and open a terminal in the project folder.
3. Run `npm install`
4. Copy `.env.example` to `.env` and fill values.
5. Run `npm start`
6. Open `http://localhost:3000` in your browser.

## Security features included
- Helmet with CSP and HSTS
- CSRF protection using csurf + cookie-parser
- Rate limiting
- Input validation on example endpoints
- Sanitization for user-provided content

## Files to inspect
- server.js — main server with security middlewares
- public/* — front-end files
- .env.example — environment variables sample

## Next steps (for new coders)

1. Add authentication: README includes guidance to add bcrypt and sessions or JWT.
2. Use S3/presigned URLs for secure downloads.
3. Add HTTPS in production.

## Troubleshooting
- If port is in use change PORT in `.env`.
- If `npm install` errors, upgrade npm or node to latest LTS.
