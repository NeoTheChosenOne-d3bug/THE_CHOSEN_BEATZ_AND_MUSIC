require('dotenv').config();
const express = require('express');
const http = require('http');
const path = require('path');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cors = require('cors');
const csrf = require('csurf');
const cookieParser = require('cookie-parser');
const { body, validationResult } = require('express-validator');
const { Server } = require('socket.io');
const sanitizeHtml = require('sanitize-html');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.CORS_ORIGIN || '*' } });

// Basic security headers via helmet
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "https:"] ,
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'", 'ws:','wss:'],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: []
    }
  },
  hsts: { maxAge: 31536000, includeSubDomains: true }
}));

app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));
app.use(cookieParser());

// CORS - set properly in production
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));

// Rate limiter
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200 });
app.use(limiter);

// CSRF protection (uses cookies)
const csrfProtection = csrf({ cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production' } });
app.use(csrfProtection);

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Helper to send CSRF token to client as a cookie for JS to read
app.get('/api/csrf-token', (req, res) => {
  res.cookie('XSRF-TOKEN', req.csrfToken(), { secure: process.env.NODE_ENV === 'production', sameSite: 'lax' });
  res.json({ status: 'ok' });
});

// Example protected post with validation and sanitization
app.post('/api/contact', [
  body('name').trim().isLength({ min: 1 }).withMessage('Name required'),
  body('email').isEmail().withMessage('Valid email required'),
  body('message').trim().isLength({ min: 1 }).withMessage('Message required')
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const name = sanitizeHtml(req.body.name);
  const email = sanitizeHtml(req.body.email);
  const message = sanitizeHtml(req.body.message);
  // TODO: process or store message safely
  res.json({ status: 'ok' });
});

// Example signed download placeholder (implement storage provider)
app.get('/api/download/:id', (req, res) => {
  // Validate user and purchases here
  return res.status(501).json({ error: 'Not implemented. Use S3 presigned URLs.' });
});

// Socket.io with sanitization
io.on('connection', (socket) => {
  console.log('socket connected', socket.id);
  socket.on('chat.message', (raw) => {
    const safe = sanitizeHtml(raw, { allowedTags: [], allowedAttributes: {} });
    io.emit('chat.message', { id: socket.id, text: safe, ts: Date.now() });
  });
  socket.on('disconnect', () => console.log('socket disconnected', socket.id));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
