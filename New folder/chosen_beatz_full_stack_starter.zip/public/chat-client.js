async function init() {
  // Request CSRF token cookie
  await fetch('/api/csrf-token', { credentials: 'include' });
  const socket = io();
  const form = document.getElementById('chatForm');
  const input = document.getElementById('msg');
  const messages = document.getElementById('messages');
  socket.on('connect', () => console.log('connected', socket.id));
  socket.on('chat.message', (m) => {
    const li = document.createElement('li');
    li.textContent = `${new Date(m.ts).toLocaleTimeString()} — ${m.text}`;
    messages.appendChild(li);
    messages.scrollTop = messages.scrollHeight;
  });
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!input.value.trim()) return;
    socket.emit('chat.message', input.value);
    input.value = '';
  });
}
init();
