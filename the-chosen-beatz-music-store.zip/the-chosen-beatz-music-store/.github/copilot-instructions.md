# Copilot Instructions — The Chosen Beatz Music Store

## Architecture Overview

**The Chosen Beatz** is a full-stack music beats marketplace scaffold:
- **Frontend**: React + Vite + Tailwind CSS with client-side Stripe integration
- **Backend**: Express.js + PostgreSQL + JWT auth + Stripe server-side
- **Deployment**: Docker + docker-compose + nginx reverse proxy
- **Currency**: ZAR (South African Rand) — prices stored in cents

**Key Data Flows:**
1. **Auth**: Register/login returns JWT token (7-day expiry) for protected routes
2. **Products**: Fetch all beats or individual by ID; prices in `price_cents` (divide by 100 for display)
3. **Orders**: Create payment intent via Stripe, store order + order_items, stripe_payment_intent ID tracks status

## Tech Stack & Dependencies

| Layer | Framework | Key Packages |
|-------|-----------|--------------|
| Frontend | React 18 + Vite | axios, react-router-dom, @stripe/react-stripe-js, tailwindcss |
| Backend | Express | pg, bcryptjs, jsonwebtoken, stripe, multer, cors |
| Database | PostgreSQL 15 | (Docker service in compose) |
| Env Config | dotenv | (backend/.env, frontend/.env.local for VITE_ vars) |

## Project Structure

```
frontend/src/
  ├── main.jsx          # Entry point; sets up React Router
  ├── pages/
  │   ├── Home.jsx      # Landing page with nav
  │   ├── Store.jsx     # Product grid (GET /api/products)
  │   ├── Product.jsx   # Detail view (GET /api/products/:id)
  │   ├── Checkout.jsx  # Stripe Payment Intent flow
  │   └── Admin.jsx     # Protected admin dashboard
  ├── styles.css        # Tailwind + custom overrides
  └── (utilities/components TBD)

backend/src/
  ├── index.js          # Monolithic API; all routes + middleware
  └── (future: split into routes/, middleware/, services/)

db/
  └── schema.sql        # Users, products, orders, order_items tables

deploy/
  ├── docker-compose.yml # postgres, backend, frontend services
  ├── nginx.conf        # Reverse proxy (frontend → 5173, api → 4000)
  └── Dockerfile        # (in frontend/ and backend/)
```

## Essential Developer Workflows

### Frontend Development
```bash
cd frontend
npm install
npm run dev          # Vite dev server on http://localhost:5173
npm run build        # Production build to dist/
```
- **API calls**: Use `import.meta.env.VITE_API_URL` or fallback to `http://localhost:4000`
- **Auth token**: Store JWT in localStorage; add `Authorization: Bearer <token>` to axios headers
- **Route structure**: Top-level routes in `main.jsx`; nested routes via `<Routes>` nesting

### Backend Development
```bash
cd backend
npm install
npm run dev          # nodemon watches src/index.js
# Requires: DATABASE_URL, JWT_SECRET, STRIPE_SECRET_KEY in .env
```
- **Database**: Connect via `Pool` from `pg` library; use parameterized queries (e.g., `$1, $2`)
- **Auth middleware**: Check `Authorization` header, verify JWT, attach `req.user = { id, email, role }`
- **Stripe**: `stripe.paymentIntents.create()` returns `clientSecret` for frontend; store `id` in DB

### Local Full-Stack (Docker)
```bash
cd deploy
docker-compose up --build
# DB on localhost:5432 (user: postgres, pass: password)
# Backend on http://localhost:4000
# Frontend on http://localhost:5173
```

### Database Initialization
```bash
psql postgres://postgres:password@localhost:5432/chosen_beatz < db/schema.sql
```

## Code Patterns & Conventions

### Naming Conventions
- **Price storage**: Always store in cents (`price_cents` INTEGER), divide by 100 for display
- **Currency**: Hardcoded as 'ZAR' in backend (`/api/payments/create-payment-intent`)
- **Roles**: 'customer' or 'admin' in users table; check `req.user.role` in protected routes

### Frontend Pages (React)
- **State management**: Use `useState` for local component state; fetch data in `useEffect`
- **API errors**: Silently fail for now (`.catch(()=>{})` pattern); consider error boundaries later
- **Styling**: Tailwind utility classes; card components use `p-4 border rounded` base
- **Stripe integration**: Use `@stripe/react-stripe-js` — fetch `clientSecret` from backend, integrate payment modal. A sample component is provided at `frontend/src/components/CheckoutForm.jsx` which:
  - Calls `POST /api/payments/create-payment-intent` with `{ items }` and `Authorization: Bearer <token>` pulled from `localStorage` (the endpoint is protected; set a test JWT in `localStorage` for local testing).
  - Initializes `Elements` with the `clientSecret` and uses `CardElement` + `stripe.confirmCardPayment()`.
  - Exposes `orderId` returned by the backend; use `GET /api/orders/:id` to query order status (requires auth).


### Backend Routes (Express)
- **Parameterized queries**: Always use `$1, $2` placeholders with `pool.query(..., [params])`
- **Error responses**: Return `{ error: 'message' }` with appropriate HTTP status (400, 401, 404)
- **JWT payload**: Include `{ id, email, role }` in signed token
- **CORS**: Allow `origin: process.env.FRONTEND_URL` (or `'*'` in dev)

### Database Schema
- **Foreign keys**: `order_items.order_id` → `orders.id ON DELETE CASCADE`
- **Indexes**: Full-text search on `products.tags` via GIN index
- **Timestamps**: `created_at TIMESTAMP DEFAULT now()` on all tables

## Integration Points & External Services

## Testing & E2E
- A simple end-to-end payment test is included at `backend/tests/e2e_payment_test.js`.
- Prerequisites:
  - Backend server running (or run `cd backend && npm run dev`).
  - Environment variables set: `DATABASE_URL`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`.
  - `npm` and `psql` available locally.
- Run the test:
  ```bash
  cd backend
  npm install
  npm run test:e2e
  ```
- What it does:
  - Inserts a product into the DB, registers a user, calls `/api/payments/create-payment-intent`, simulates a `payment_intent.succeeded` webhook (using `stripe.webhooks.generateTestHeaderString`) and verifies the order is marked `paid`.
- If your CI should run this, ensure secrets are available as protected env vars and a test Postgres DB is available.

## Integration Points & External Services

### Stripe (Payments)
- **Client-side**: `@stripe/react-stripe-js` uses a `clientSecret` returned from `POST /api/payments/create-payment-intent` (see `frontend/src/pages/Checkout.jsx`).
- **Server-side**: `stripe.paymentIntents.create({ amount, currency, metadata })` creates intents (see `backend/src/index.js`).
- **Key files**: `backend/src/index.js`, `frontend/src/pages/Checkout.jsx`.
- **Env vars (examples)**:
  - Backend `.env`:
    ```
    DATABASE_URL=postgres://postgres:password@localhost:5432/chosen_beatz
    JWT_SECRET=change-me
    STRIPE_SECRET_KEY=sk_test_xxx
    STRIPE_WEBHOOK_SECRET=whsec_xxx
    FRONTEND_URL=http://localhost:5173
    PORT=4000
    ```
  - Frontend `.env.local`:
    ```
    VITE_API_URL=http://localhost:4000
    VITE_STRIPE_PUBLISHABLE_KEY=pk_test_xxx
    ```
- **Webhooks (recommended)**:
  - Add a webhook endpoint `POST /api/payments/webhook` in `backend/src/index.js` to handle events such as `payment_intent.succeeded`.
  - Use `stripe.webhooks.constructEvent(rawBody, sigHeader, process.env.STRIPE_WEBHOOK_SECRET)` to validate signatures. Store `STRIPE_WEBHOOK_SECRET` in backend `.env`.
  - On `payment_intent.succeeded`, update the corresponding order (`orders.status = 'paid'`) by matching `stripe_payment_intent`.
  - Implementation notes:
    - Use `express.raw({type: 'application/json'})` for the webhook route so you can validate the raw body.
    - Read the signature from the `Stripe-Signature` header.
    - Keep the handler fast and return 2xx quickly; perform heavier work asynchronously if needed.
  - Testing locally: run `stripe listen --forward-to localhost:4000/api/payments/webhook` (or use ngrok). The Stripe CLI prints a `webhook signing secret` (whsec_...) — copy it into `backend/.env` as `STRIPE_WEBHOOK_SECRET`.
  - You can trigger sample events locally with `stripe trigger payment_intent.succeeded` (for quick end-to-end checks) or create a real test PaymentIntent from the frontend and then trigger events from the CLI.
- **Security**: Never log webhook payloads or secret values in production; verify signatures and respond with appropriate HTTP statuses.

### PostgreSQL
- **Connection**: `Pool({ connectionString: process.env.DATABASE_URL })`
- **Seeding**: Populate `products` table for store; see `db/schema.sql` for structure
- **Queries**: Prefer read-only queries on `/api/products` endpoints; write-heavy on `/api/payments` and `/api/auth`

### File Uploads (Audio)
- **Storage**: Schema includes `file_path` (VARCHAR) in products table
- **Not yet implemented**: Use `multer` + S3 bucket or local `/uploads` directory
- **Future pattern**: POST endpoint to accept audio file → store path → reference in product

## Common Tasks & Patterns

### Adding a New API Endpoint
1. Add route handler in `backend/src/index.js`
2. Use `app.get()`, `app.post()`, etc. with same error/response pattern
3. Protect with `authMiddleware` if user context required
4. Call from frontend component via `axios.get()` or similar

### Creating a New Frontend Page
1. Create `.jsx` file in `frontend/src/pages/`
2. Import at top of `main.jsx`, add route in `<Routes>`
3. Use `useEffect(() => { axios.get(...) })` to fetch data
4. Style with Tailwind classes; follow grid/card pattern from `Store.jsx`

### Adding Product Metadata
- **Music-specific fields**: `bpm` (INTEGER), `key` (VARCHAR), `tags` (VARCHAR) already in schema
- **Future**: Consider `genre`, `mood`, `artist` columns; update API response filtering

## Gotchas & Known Limitations

- **No input validation**: Backend accepts any request body; sanitize before production
- **No error boundaries**: Frontend silently fails on API errors; wrap in error handler
- **No logging**: Use `console.log()` for now; add structured logging (Winston, pino) before production
- **Auth state**: Token only stored in localStorage; no refresh logic; expires after 7 days
- **Admin routes**: Placeholder only; implement role checks on backend (/api/admin/*)
- **Audio delivery**: Not implemented; file_path is metadata only
- **Production secrets**: Replace `.env.example` values before deployment

## File References

- **Architecture rationale**: `docs/architecture.md`, `docs/api-spec.md`
- **Design system**: `docs/ui-ux-guide.md` (design tokens, accessibility)
- **Deployment**: `deploy/docker-compose.yml`, `deploy/nginx.conf`
- **Schema reference**: `db/schema.sql` (run on init)
