/*
  End-to-end payment flow test (local)
  - Inserts a product into DB
  - Registers a user and logs in (gets JWT)
  - Calls POST /api/payments/create-payment-intent with product items
  - Reads the order from DB and extracts stripe_payment_intent id
  - Simulates Stripe webhook `payment_intent.succeeded` by POSTing to /api/payments/webhook
  - Verifies order.status === 'paid'

  Requirements: run backend server (npm run dev) and set these env vars:
    - DATABASE_URL
    - STRIPE_SECRET_KEY
    - STRIPE_WEBHOOK_SECRET
    - TEST_API_URL (optional, default http://localhost:4000)
*/

const axios = require('axios')
const { Pool } = require('pg')
const Stripe = require('stripe')

async function run(){
  const dbUrl = process.env.DATABASE_URL
  const stripeKey = process.env.STRIPE_SECRET_KEY
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET
  const apiUrl = process.env.TEST_API_URL || 'http://localhost:4000'

  if(!dbUrl || !stripeKey || !webhookSecret){
    console.error('Missing required env vars. Please set DATABASE_URL, STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET')
    process.exit(2)
  }

  const pool = new Pool({ connectionString: dbUrl })
  const stripe = Stripe(stripeKey)

  let product = null
  let user = null
  let orderId = null

  try{
    // insert product
    const prodRes = await pool.query("INSERT INTO products (title,description,price_cents) VALUES ($1,$2,$3) RETURNING id,price_cents", ['E2E Test Beat','Auto-created product for e2e test', 1999])
    product = prodRes.rows[0]
    console.log('Created product id=', product.id)

    // register a user
    const testEmail = `e2e-${Date.now()}@example.com`
    const reg = await axios.post(apiUrl + '/api/auth/register', { email: testEmail, password: 'password123', name: 'E2E Tester' })
    if(!reg || !reg.data || !reg.data.token || !reg.data.user){
      throw new Error('Registration failed or unexpected response: ' + JSON.stringify(reg && reg.data))
    }
    const token = reg.data.token
    user = reg.data.user
    console.log('Registered user; id=', user.id)

    // create payment intent via backend
    const r = await axios.post(apiUrl + '/api/payments/create-payment-intent', { items: [{ productId: product.id, quantity: 1 }] }, { headers: { Authorization: 'Bearer ' + token } })
    if(!r || !r.data || !r.data.clientSecret || !r.data.orderId){
      throw new Error('create-payment-intent failed: ' + JSON.stringify(r && r.data))
    }
    console.log('create-payment-intent response keys:', Object.keys(r.data))
    orderId = r.data.orderId

    // fetch order from DB to get stripe_payment_intent
    const ordRes = await pool.query('SELECT * FROM orders WHERE id=$1', [orderId])
    if(!ordRes.rows[0]){
      throw new Error('Order not found after create')
    }
    const order = ordRes.rows[0]
    console.log('Order created id=', order.id, 'stripe_payment_intent=', order.stripe_payment_intent)

    // Simulate webhook event for payment_intent.succeeded
    const event = {
      id: 'evt_test_' + Date.now(),
      object: 'event',
      type: 'payment_intent.succeeded',
      data: { object: { id: order.stripe_payment_intent } }
    }
    const payload = JSON.stringify(event)
    const sig = stripe.webhooks.generateTestHeaderString({ payload, secret: webhookSecret })

    const webhookResp = await axios.post(apiUrl + '/api/payments/webhook', payload, { headers: { 'Content-Type': 'application/json', 'Stripe-Signature': sig } })
    if(!webhookResp || webhookResp.status < 200 || webhookResp.status >= 300){
      throw new Error('Webhook POST failed: ' + (webhookResp && webhookResp.status))
    }
    console.log('Webhook response status:', webhookResp.status)

    // confirm order status updated
    const ordRes2 = await pool.query('SELECT status FROM orders WHERE id=$1', [orderId])
    console.log('Order status after webhook:', ordRes2.rows[0].status)
    if(ordRes2.rows[0].status !== 'paid'){
      throw new Error('Order did not update to paid')
    }

    console.log('E2E payment flow succeeded ✅')

  }catch(err){
    console.error('E2E test failed:', err && err.message ? err.message : err)
    process.exitCode = 1
  }finally{
    // cleanup - best effort, ignore errors
    try{
      if(orderId){
        await pool.query('DELETE FROM order_items WHERE order_id=$1', [orderId])
        await pool.query('DELETE FROM orders WHERE id=$1', [orderId])
        console.log('Deleted order and order_items id=', orderId)
      }
    }catch(e){ console.error('Failed to cleanup order:', e && e.message) }

    try{
      if(user && user.id){
        await pool.query('DELETE FROM users WHERE id=$1', [user.id])
        console.log('Deleted test user id=', user.id)
      }
    }catch(e){ console.error('Failed to cleanup user:', e && e.message) }

    try{
      if(product && product.id){
        await pool.query('DELETE FROM products WHERE id=$1', [product.id])
        console.log('Deleted test product id=', product.id)
      }
    }catch(e){ console.error('Failed to cleanup product:', e && e.message) }

    try{ await pool.end() }catch(e){ /* ignore */ }

    // exit with the appropriate code
    if(process.exitCode && process.exitCode !== 0) process.exit(process.exitCode)
    process.exit(0)
  }
}

run().catch(err=>{ console.error(err); process.exit(1) })
