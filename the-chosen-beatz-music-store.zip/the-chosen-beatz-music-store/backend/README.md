# Backend — Run & Test

This file explains how to run the backend locally and run the end-to-end payment test.

Prerequisites
- Node.js and npm installed
- PostgreSQL running (or use Docker with `docker-compose`) 
- Stripe CLI installed (optional but required for webhook local testing)

1) Start the database (Docker, recommended):

```powershell
cd deploy
docker-compose up -d db
```

2) Create the database schema (run once):

```powershell
psql postgres://postgres:password@localhost:5432/chosen_beatz < db/schema.sql
```

3) Create a `.env` file in `backend/` with the following minimum values:

```
DATABASE_URL=postgres://postgres:password@localhost:5432/chosen_beatz
JWT_SECRET=change-me
STRIPE_SECRET_KEY=sk_test_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx   # fill after running `stripe listen`
FRONTEND_URL=http://localhost:5173
PORT=4000
```

4) Install deps and run backend in dev mode:

```powershell
cd backend
npm install
npm run dev
```

5) (Optional) Obtain a webhook signing secret from the Stripe CLI:

```powershell
stripe listen --forward-to localhost:4000/api/payments/webhook
```

The CLI prints a `Webhook signing secret` (whsec_...). Copy that into `backend/.env` as `STRIPE_WEBHOOK_SECRET` and restart the backend.

6) Run the end-to-end test (backend must be running):

```powershell
cd backend
npm install
npm run test:e2e
```

Troubleshooting
- If `npm` isn't recognized, install Node.js from https://nodejs.org/
- If the test fails to reach the backend, make sure `PORT` and `DATABASE_URL` are correct and backend is running
- For webhook debugging, use `stripe trigger payment_intent.succeeded` after `stripe listen` is running

Security note: Do not store real secrets in Git; use CI secret storage and environment variables.
