/**
 * Simple Express API scaffold for The Chosen Beatz
 * - Auth (register/login)
 * - Products list
 * - Orders + Stripe Payment Intent
 *
 * Replace DATABASE_URL, JWT_SECRET and STRIPE_SECRET_KEY in .env
 */
const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const stripeLib = require('stripe');
const multer = require('multer');

require('dotenv').config();
const PORT = process.env.PORT || 4000;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const stripe = stripeLib(process.env.STRIPE_SECRET_KEY || "");

const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(express.json());

// simple auth helpers
function signToken(user) {
  return jwt.sign({ id: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
}
function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: 'no token' });
  const token = auth.split(' ')[1];
  try {
    const data = jwt.verify(token, process.env.JWT_SECRET);
    req.user = data;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'invalid token' });
  }
}

// routes: auth
app.post('/api/auth/register', async (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'missing fields' });
  const hashed = await bcrypt.hash(password, 10);
  const r = await pool.query('INSERT INTO users (email, password_hash, name) VALUES ($1,$2,$3) RETURNING id,email,role', [email, hashed, name||null]);
  const user = r.rows[0];
  const token = signToken(user);
  res.json({ user, token });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const r = await pool.query('SELECT id,email,password_hash,role FROM users WHERE email=$1', [email]);
  const user = r.rows[0];
  if (!user) return res.status(400).json({ error: 'invalid credentials' });
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(400).json({ error: 'invalid credentials' });
  const token = signToken(user);
  res.json({ user: { id: user.id, email: user.email, role: user.role }, token });
});

// products
app.get('/api/products', async (req, res) => {
  const r = await pool.query('SELECT id,title,description,price_cents,currency,bpm,key,tags FROM products ORDER BY created_at DESC LIMIT 100');
  res.json(r.rows);
});
app.get('/api/products/:id', async (req, res) => {
  const r = await pool.query('SELECT * FROM products WHERE id=$1', [req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'not found' });
  res.json(r.rows[0]);
});

// create order -> create Stripe Payment Intent
app.post('/api/payments/create-payment-intent', authMiddleware, async (req, res) => {
  const { items } = req.body; // [{productId, quantity}]
  if (!items || !Array.isArray(items)) return res.status(400).json({ error: 'invalid items' });
  // naive total calc - in production refetch prices server-side from DB
  let totalCents = 0;
  for (const it of items) {
    const r = await pool.query('SELECT price_cents FROM products WHERE id=$1', [it.productId]);
    if (!r.rows[0]) return res.status(400).json({ error: 'product not found: ' + it.productId });
    totalCents += r.rows[0].price_cents * (it.quantity||1);
  }
  const paymentIntent = await stripe.paymentIntents.create({
    amount: totalCents,
    currency: 'zar',
    metadata: { userId: req.user.id.toString() },
  });
  // create order record
  const orderRes = await pool.query('INSERT INTO orders (user_id,total_cents,currency,status,stripe_payment_intent) VALUES ($1,$2,$3,$4,$5) RETURNING id', [req.user.id, totalCents, 'ZAR', 'pending', paymentIntent.id]);
  // create items
  for (const it of items) {
    const r = await pool.query('SELECT price_cents FROM products WHERE id=$1', [it.productId]);
    await pool.query('INSERT INTO order_items (order_id,product_id,price_cents,quantity) VALUES ($1,$2,$3,$4)', [orderRes.rows[0].id, it.productId, r.rows[0].price_cents, it.quantity||1]);
  }
  res.json({ clientSecret: paymentIntent.client_secret, orderId: orderRes.rows[0].id });
});

// get order (protected) — returns order and items; admin can access any order
app.get('/api/orders/:id', authMiddleware, async (req, res) => {
  const r = await pool.query('SELECT * FROM orders WHERE id=$1', [req.params.id]);
  const order = r.rows[0];
  if (!order) return res.status(404).json({ error: 'not found' });
  if (req.user.role !== 'admin' && order.user_id !== req.user.id) return res.status(403).json({ error: 'forbidden' });
  const items = await pool.query('SELECT * FROM order_items WHERE order_id=$1', [req.params.id]);
  res.json({ order, items: items.rows });
});

// Stripe webhook endpoint — must use raw body to validate signature
app.post('/api/payments/webhook', express.raw({type: 'application/json'}), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!secret) return res.status(400).send('stripe webhook secret not configured');
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, secret);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Handle the event
  if (event.type === 'payment_intent.succeeded') {
    const pi = event.data.object;
    try {
      await pool.query("UPDATE orders SET status='paid' WHERE stripe_payment_intent=$1", [pi.id]);
      console.log('Order updated to paid for payment intent', pi.id);
    } catch (e) {
      console.error('Failed to update order status for', pi.id, e);
    }
  }

  // Return a 200 to acknowledge receipt of the event
  res.json({ received: true });
});

// admin stats (protected, role check)
app.get('/api/admin/stats', authMiddleware, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'forbidden' });
  const users = await pool.query('SELECT COUNT(*) FROM users');
  const sales = await pool.query("SELECT COALESCE(SUM(total_cents),0) FROM orders WHERE status!='cancelled'");
  res.json({ users: users.rows[0].count, total_sales_cents: sales.rows[0].coalesce || sales.rows[0].sum || 0 });
});

app.listen(PORT, ()=> console.log('Backend listening on', PORT));
