<#
Start-Dev.ps1 — Bring up local dev stack (Postgres, backend, frontend) and run health checks.

Usage:
  # basic: starts DB, schema, backend, frontend, opens browser
  pwsh ./scripts/start-dev.ps1

  # include Stripe listener (requires Stripe CLI installed and logged in)
  pwsh ./scripts/start-dev.ps1 -StartStripe

Notes:
- Requires Docker (for Postgres), Node/npm, psql (optional but recommended), Chrome (optional).
- Edit `backend/.env` and `frontend/.env.local` before running to set API keys and Stripe keys.
#>

[CmdletBinding()]
param(
  [switch]$StartStripe
)

function Write-Info($msg){ Write-Host "[INFO] $msg" -ForegroundColor Cyan }
function Write-Err($msg){ Write-Host "[ERROR] $msg" -ForegroundColor Red }
function Write-Succ($msg){ Write-Host "[OK] $msg" -ForegroundColor Green }

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = Resolve-Path (Join-Path $scriptDir '..')

Write-Info "Repo root: $repoRoot"

# Check required commands
function Test-CommandExists($cmd){
  $null -ne (Get-Command $cmd -ErrorAction SilentlyContinue)
}

if(-not (Test-CommandExists docker)){
  Write-Err "Docker is not installed or not in PATH. Install Docker Desktop and try again."
  exit 1
}
if(-not (Test-CommandExists npm)){
  Write-Err "npm not found. Install Node.js (includes npm)."
  exit 1
}

Write-Info "Starting Postgres (docker-compose service 'db')"
Push-Location (Join-Path $repoRoot 'deploy')
docker-compose up -d db
Pop-Location

# Wait for TCP port 5432 to be open
$attempts = 0
while($attempts -lt 30){
  $c = Test-NetConnection -ComputerName 'localhost' -Port 5432 -WarningAction SilentlyContinue
  if($c.TcpTestSucceeded){ Write-Succ 'Postgres port 5432 open'; break }
  Start-Sleep -Seconds 1
  $attempts++
}
if($attempts -ge 30){ Write-Err 'Postgres did not become available on port 5432'; exit 1 }

# Initialize DB schema (requires psql)
if(Test-CommandExists psql){
  Write-Info 'Initializing DB schema using psql'
  $dbUrl = 'postgres://postgres:password@localhost:5432/chosen_beatz'
  psql $dbUrl -f (Join-Path $repoRoot 'db\schema.sql')
  Write-Succ 'DB schema applied'
} else {
  Write-Info 'psql not found; skipping automatic schema initialization. Run manually: psql <connection> -f db/schema.sql'
}

# Ensure backend .env exists
$backendEnv = Join-Path $repoRoot 'backend\.env'
if(-not (Test-Path $backendEnv)){
  Write-Info "Creating sample backend .env at $backendEnv (edit values before running)"
  @"
DATABASE_URL=postgres://postgres:password@localhost:5432/chosen_beatz
JWT_SECRET=change-me
STRIPE_SECRET_KEY=sk_test_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx
FRONTEND_URL=http://localhost:5173
PORT=4000
"@ | Out-File -FilePath $backendEnv -Encoding UTF8
  Write-Info 'Please edit backend/.env to set real keys (STRIPE_* values) if needed.'
}

# Start backend
Write-Info 'Starting backend (npm run dev)'
$backendProc = Start-Process npm -ArgumentList 'run','dev' -WorkingDirectory (Join-Path $repoRoot 'backend') -PassThru

# Wait for backend health
$attempts = 0
while($attempts -lt 40){
  try{
    $r = Invoke-WebRequest -UseBasicParsing -Uri http://localhost:4000/api/products -TimeoutSec 2 -ErrorAction Stop
    if($r.StatusCode -ge 200 -and $r.StatusCode -lt 300){ Write-Succ 'Backend ready at http://localhost:4000'; break }
  }catch{}
  Start-Sleep -Seconds 1
  $attempts++
}
if($attempts -ge 40){ Write-Err 'Backend did not become healthy on http://localhost:4000/api/products'; exit 1 }

# Ensure frontend .env.local exists
$frontendEnv = Join-Path $repoRoot 'frontend\.env.local'
if(-not (Test-Path $frontendEnv)){
  Write-Info "Creating sample frontend .env.local at $frontendEnv (edit values before running)"
  @"
VITE_API_URL=http://localhost:4000
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_xxx
"@ | Out-File -FilePath $frontendEnv -Encoding UTF8
  Write-Info 'Please edit frontend/.env.local to set STRIPE publishable key if needed.'
}

# Start frontend
Write-Info 'Starting frontend (npm run dev)'
$frontendProc = Start-Process npm -ArgumentList 'run','dev' -WorkingDirectory (Join-Path $repoRoot 'frontend') -PassThru

# Wait for frontend health
$attempts = 0
while($attempts -lt 30){
  try{
    $r = Invoke-WebRequest -UseBasicParsing -Uri http://localhost:5173 -TimeoutSec 2 -ErrorAction Stop
    if($r.StatusCode -ge 200 -and $r.StatusCode -lt 400){ Write-Succ 'Frontend ready at http://localhost:5173'; break }
  }catch{}
  Start-Sleep -Seconds 1
  $attempts++
}
if($attempts -ge 30){ Write-Err 'Frontend did not become ready at http://localhost:5173'; exit 1 }

# Optionally start Stripe CLI listener
if($StartStripe){
  if(-not (Test-CommandExists stripe)){
    Write-Err 'stripe CLI not found; install it to enable webhook forwarding.'
  } else {
    Write-Info 'Starting Stripe CLI (stripe listen --forward-to http://localhost:4000/api/payments/webhook)'
    Start-Process stripe -ArgumentList 'listen','--forward-to','http://localhost:4000/api/payments/webhook' -NoNewWindow -WorkingDirectory $repoRoot
    Write-Info 'Stripe listen started (check its terminal output for the whsec_.. secret)'
  }
}

# Open browser to frontend
if(Test-CommandExists chrome){
  Start-Process chrome 'http://localhost:5173'
} else {
  Write-Info 'Chrome not found in PATH; open http://localhost:5173 in your browser manually.'
}

Write-Succ 'All services started. Tail logs in the respective directories if needed.'

Write-Host "\nUseful commands:\n  # Backend logs\n  cd backend ; # observe nodemon output\n  # Frontend logs\n  cd frontend ; # observe Vite output\n  # Stop DB\n  cd deploy ; docker-compose down"
