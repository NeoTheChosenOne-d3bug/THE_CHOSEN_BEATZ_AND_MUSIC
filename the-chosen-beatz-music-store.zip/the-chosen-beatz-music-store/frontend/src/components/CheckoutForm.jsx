import React, {useEffect, useState} from 'react'
import axios from 'axios'
import {loadStripe} from '@stripe/stripe-js'
import {Elements, CardElement, useStripe, useElements} from '@stripe/react-stripe-js'

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || '')

function InnerForm({clientSecret, orderId}){
  const stripe = useStripe()
  const elements = useElements()
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState(null)

  const handleSubmit = async (e)=>{
    e.preventDefault()
    if(!stripe || !elements) return
    setLoading(true)
    const card = elements.getElement(CardElement)
    const res = await stripe.confirmCardPayment(clientSecret, {payment_method: {card}})
    setLoading(false)
    if(res.error) return setMessage(res.error.message)
    if(res.paymentIntent && res.paymentIntent.status === 'succeeded'){
      setMessage('Payment succeeded — order ' + orderId)
    } else {
      setMessage('Payment processing: ' + (res.paymentIntent?.status || 'unknown'))
    }
  }

  return (
    <form onSubmit={handleSubmit} className="mt-4">
      <div className="p-4 border rounded">
        <CardElement options={{hidePostalCode: true}} />
      </div>
      <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded" disabled={!stripe || loading}>
        {loading ? 'Processing…' : 'Pay'}
      </button>
      {message && <p className="mt-2">{message}</p>}
    </form>
  )
}

export default function CheckoutForm({items}){
  const [clientSecret, setClientSecret] = useState(null)
  const [orderId, setOrderId] = useState(null)
  const api = import.meta.env.VITE_API_URL || 'http://localhost:4000'

  useEffect(()=>{
    async function createIntent(){
      try{
        const token = localStorage.getItem('token')
        const headers = token ? { Authorization: 'Bearer ' + token } : {}
        const r = await axios.post(api + '/api/payments/create-payment-intent', { items }, { headers })
        setClientSecret(r.data.clientSecret)
        setOrderId(r.data.orderId)
      }catch(e){
        console.error('createPaymentIntent error', e)
      }
    }
    createIntent()
  }, [items])

  if(!clientSecret) return <p className="mt-4">Preparing payment…</p>

  return (
    <Elements stripe={stripePromise} options={{clientSecret}}>
      <InnerForm clientSecret={clientSecret} orderId={orderId} />
    </Elements>
  )
}
