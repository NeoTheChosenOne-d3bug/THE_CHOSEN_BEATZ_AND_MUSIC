import React, {useEffect, useState} from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import axios from 'axios'

export default function Product(){
  const { id } = useParams()
  const [product, setProduct] = useState(null)
  const nav = useNavigate()
  useEffect(()=>{ axios.get((import.meta.env.VITE_API_URL||'http://localhost:4000')+'/api/products/'+id).then(r=>setProduct(r.data)).catch(()=>{}) },[id])
  if(!product) return <div className="p-8">Loading...</div>
  return (
    <main className="p-8 max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold">{product.title}</h2>
      <p className="mt-4">{product.description}</p>
      <p className="mt-4 font-semibold">R{(product.price_cents/100).toFixed(2)}</p>
      <button onClick={()=>{ nav('/checkout', { state: { items: [{productId: product.id, quantity:1}] } }) }} className="mt-4 px-4 py-2 rounded shadow">Buy</button>
    </main>
  )
}
