import React from 'react'
export default function Admin(){
  return (
    <main className="p-8 max-w-6xl mx-auto">
      <h2 className="text-3xl font-bold">Admin Panel (Scaffold)</h2>
      <p className="mt-4">This panel should be protected by authentication and show orders, product management and stats.</p>
    </main>
  )
}
