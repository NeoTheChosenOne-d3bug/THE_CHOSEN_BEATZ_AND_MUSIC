import React from 'react'
import { Link } from 'react-router-dom'
export default function Home(){ 
  return (
    <main className="min-h-screen p-8">
      <header className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold">The Chosen Beatz</h1>
        <p className="mt-2 text-lg">Premium beats for producers & artists.</p>
        <nav className="mt-4">
          <Link to="/store" className="underline">Browse Beats</Link> · <Link to="/admin">Admin</Link>
        </nav>
      </header>
      <section className="mt-8 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="card p-6 rounded-lg shadow">
            <h3 className="text-xl font-semibold">Featured Beats</h3>
            <p className="mt-2">Hand-picked hot beats.</p>
          </div>
          <div className="card p-6 rounded-lg shadow">
            <h3 className="text-xl font-semibold">Licensing</h3>
            <p className="mt-2">Clear, easy licensing for all use cases.</p>
          </div>
          <div className="card p-6 rounded-lg shadow">
            <h3 className="text-xl font-semibold">Producer Profiles</h3>
            <p className="mt-2">Showcase credits and contact.</p>
          </div>
        </div>
      </section>
    </main>
  )
}
