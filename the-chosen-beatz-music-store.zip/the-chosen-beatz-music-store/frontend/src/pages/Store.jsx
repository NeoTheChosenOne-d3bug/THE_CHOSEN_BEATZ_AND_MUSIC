import React, {useEffect, useState} from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'
export default function Store(){
  const [products, setProducts] = useState([])
  useEffect(()=>{ axios.get((import.meta.env.VITE_API_URL||'http://localhost:4000')+'/api/products').then(r=>setProducts(r.data)).catch(()=>{}) },[])
  return (
    <main className="min-h-screen p-8 max-w-6xl mx-auto">
      <h2 className="text-3xl font-bold">Store</h2>
      <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map(p=>(
          <article key={p.id} className="p-4 border rounded">
            <h3 className="font-semibold">{p.title}</h3>
            <p className="mt-2 text-sm">{p.description}</p>
            <p className="mt-2 font-medium">R{(p.price_cents/100).toFixed(2)}</p>
            <Link to={'/product/'+p.id} className="mt-3 inline-block underline">View</Link>
          </article>
        ))}
      </div>
    </main>
  )
}
