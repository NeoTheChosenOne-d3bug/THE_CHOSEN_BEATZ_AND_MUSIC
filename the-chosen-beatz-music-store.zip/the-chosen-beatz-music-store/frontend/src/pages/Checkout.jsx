import React from 'react'
import { useLocation } from 'react-router-dom'
import CheckoutForm from '../components/CheckoutForm'

export default function Checkout(){
  const loc = useLocation()
  const items = loc.state?.items || []
  return (
    <main className="p-8 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold">Checkout</h2>
      <div className="mt-4">
        <CheckoutForm items={items} />
      </div>
    </main>
  )
}
