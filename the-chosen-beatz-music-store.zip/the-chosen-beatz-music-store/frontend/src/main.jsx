import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import Store from './pages/Store'
import Product from './pages/Product'
import Checkout from './pages/Checkout'
import Admin from './pages/Admin'
import './styles.css'

createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <Routes>
      <Route path='/' element={<Home/>}/>
      <Route path='/store' element={<Store/>}/>
      <Route path='/product/:id' element={<Product/>}/>
      <Route path='/checkout' element={<Checkout/>}/>
      <Route path='/admin/*' element={<Admin/>}/>
    </Routes>
  </BrowserRouter>
)
