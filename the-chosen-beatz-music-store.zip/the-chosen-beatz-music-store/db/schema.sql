-- PostgreSQL schema for The Chosen Beatz

CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(255),
  role VARCHAR(50) DEFAULT 'customer', -- 'customer' or 'admin'
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE products (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  price_cents INTEGER NOT NULL,
  currency VARCHAR(10) DEFAULT 'ZAR',
  file_path VARCHAR(1024), -- storage reference (S3 key or local path)
  bpm INTEGER,
  key VARCHAR(16),
  tags VARCHAR(255),
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE orders (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  total_cents INTEGER NOT NULL,
  currency VARCHAR(10) DEFAULT 'ZAR',
  status VARCHAR(50) DEFAULT 'pending',
  stripe_payment_intent VARCHAR(255),
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE order_items (
  id SERIAL PRIMARY KEY,
  order_id INTEGER REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER REFERENCES products(id),
  price_cents INTEGER NOT NULL,
  quantity INTEGER DEFAULT 1
);

-- indexes for search
CREATE INDEX idx_products_tags ON products USING gin (to_tsvector('english', coalesce(tags,'')));
