# UI / UX Premium Redesign Guide

## Key principles
- Clear hierarchy: large headline, supporting subtitle, clear CTAs.
- Immersive hero with audio preview (autoplay muted loop) and waveform visual.
- Large album-art-style cards for beats; show BPM, key, tags, and license options.
- Accessible forms (labels, aria-*), keyboard nav, and enough color contrast.

## Design system
- Primary: #7c3aed (Purple)
- Background: #f8fafc
- Surface: #ffffff
- Accent: #06b6d4 (for subtle CTAs)
- Typography: Inter var for UI, Playfair for headings (optional)

## Components to build
- Hero (audio preview, CTA)
- Beat Card (preview, license selector)
- Checkout modal (compact, mobile-first)
- Admin Dashboard (sales graph, top beats, recent orders)

## Accessibility checklist
- Keyboard focus visible
- Contrast ratios >= 4.5:1 where needed
- Descriptive alt text for images
- Semantic HTML usage

