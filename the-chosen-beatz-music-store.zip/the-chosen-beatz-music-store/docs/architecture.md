# Architecture Overview

- Client (React, Vite) — SPA with routes: Home, Store, Product, Checkout, Account, Admin.
- API (Express) — REST endpoints:
  - `POST /api/auth/register`, `POST /api/auth/login`
  - `GET /api/products`, `GET /api/products/:id`
  - `POST /api/orders` (create order)
  - `POST /api/payments/create-payment-intent` (Stripe)
  - `GET /api/admin/stats` (admin)
- Database: PostgreSQL (recommended). Schema included in `db/schema.sql`.
- Payments: Stripe (Payment Intents + webhooks).
- Deployment: Docker images for frontend & backend + nginx as reverse proxy + Certbot for TLS.

Security & Notes:
- Use HTTPS in production.
- Store JWT secret and Stripe keys in environment variables.
- Validate uploaded audio files; use S3 for storage (not included but documented).

