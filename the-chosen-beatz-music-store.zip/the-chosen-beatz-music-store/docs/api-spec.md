# API Spec (Summary)

- POST /api/auth/register
  - body: { email, password, name }
  - returns: { user, token }

- POST /api/auth/login
  - body: { email, password }
  - returns: { user, token }

- GET /api/products
  - returns: [ {id,title,description,price_cents,...} ]

- GET /api/products/:id
  - returns: product

- POST /api/payments/create-payment-intent
  - headers: Authorization: Bearer <token>
  - body: { items: [{productId,quantity}] }
  - returns: { clientSecret, orderId }

- GET /api/orders/:id
  - headers: Authorization: Bearer <token>
  - returns: { order, items }

- POST /api/payments/webhook
  - webhook endpoint used by Stripe; verifies `Stripe-Signature` header and `STRIPE_WEBHOOK_SECRET`
  - handles `payment_intent.succeeded` and updates `orders.status = 'paid'` by `stripe_payment_intent`
